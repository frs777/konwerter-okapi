# Status projektu Konwerter Okapi

## 2026-10-06

Projekt został wydzielony z tlumacz-v4 do niezależnego katalogu:

/home/frs/Projekty/konwerter-okapi

Utworzono architekturę B+R zgodną z zatwierdzoną koncepcją Analyzer -> Filter IR -> Generator -> Python Core -> Differential Testing.

Skopiowano:
- wcześniejszy prototyp Python Markdown do research/filtry-python-prototyp/,
- pakiety filtrów Okapi wraz z JAR-ami do testdata/okapi-filters-java/.

Źródła w tlumacz-v4 pozostają nienaruszone.

## Następny etap

1. Kontrakty Filter IR.
2. Pierwszy test TDD dla modelu dokumentu/eventów.
3. Minimalny Python Filter Core.
4. Analyzer JAR dla filtra Markdown.
5. Oracle i differential testing.


## TDD — pierwszy cykl

Dodano minimalny model dokumentu i zdarzeń:
- Code,
- TextFragment,
- TextUnit,
- Skeleton,
- EventType,
- Event,
- StartDocument,
- DocumentPart,
- Ending.

Test najpierw zakończył się RED z powodu braku modułu. Po minimalnej implementacji wynik: 4 passed. Dodatkowo compileall dla core/document i core/events zakończył się bez błędów.

## 2026-10-06 — Filter IR

Dodano pierwszy formalny model Filter IR:
- `FilterIR`,
- `FilterIRValidationError`.

Zakres walidacji: nazwa, wersja, MIME, rozszerzenia z kropką oraz deklaracja cech.

TDD:
- test Filter IR najpierw RED z powodu braku modułu,
- minimalna implementacja,
- wynik po implementacji: 7 passed łącznie z wcześniejszym modelem dokumentu/eventów.

## 2026-10-06 — Python Filter Core

Dodano minimalny kontrakt rdzenia:
- `core/reader/base.py` — Reader,
- `core/writer/base.py` — Writer,
- `core/filter.py` — przepływ Reader -> Event -> Writer.

TDD:
- test uruchomiony przed implementacją i zakończony RED z powodu braku `core.filter`,
- minimalna implementacja,
- wynik testów: 8 passed dla modelu dokumentu, Filter IR i Filter Core,
- `compileall` dla `core` i `filter_ir`: bez błędów.

Uwaga: Git zgłosił `dubious ownership` przy próbie `git status`; nie zmieniano globalnej konfiguracji Git.
## 2026-10-06 — Zmiana PoC: DOCX/OpenXML

Na podstawie decyzji projektowej zmieniono rolę pierwszego filtra:
- Markdown nie jest już traktowany jako główny filtr referencyjny; pozostaje smoke testem prostego rdzenia.
- DOCX/OpenXML został wybrany jako pierwszy pełny filtr referencyjny, ponieważ wymusza pracę z kontenerem ZIP, wieloma częściami XML, relacjami, strukturą dokumentu, inline content, protected content i round-trip.

Wykonano backup przed zmianą:
- backups/20261006-docx-pivot/pre-change.tar.gz
- SHA-256: d17d16a4e5efdc15f27c2c6ec6f8d7d763c08ce35914884143f8b7cb915bb534

### TDD DOCX — pierwszy cykl

Dodano:
- tests/test_docx_reference.py
- filters/__init__.py
- filters/docx/__init__.py
- filters/docx/reader.py
- fixtures/docx/reference.docx

RED:
- testy początkowo nie posiadały modułu filters.docx.reader;
- po usunięciu błędu importu testy zakończyły się kontrolowanym wynikiem 3 failed z asercją braku modułu.

GREEN:
- minimalny DocxReader używa wyłącznie standardowej biblioteki Python (zipfile, xml.etree.ElementTree);
- rozpoznaje akapity, runy tekstowe, hyperlinki, tabele i proste pola chronione;
- hyperlink jest reprezentowany jako strukturalny Code(kind="hyperlink");
- chronione pole jako Code(kind="protected");
- tabela generuje odrębne TextUnit.

Weryfikacja:
- python3 -m pytest -q tests/test_docx_reference.py → 3 passed
- python3 -m pytest -q tests/test_document_model.py tests/test_filter_ir.py tests/test_filter_core.py → 8 passed

Ograniczenia aktualnego etapu:
- brak writer'a DOCX,
- brak pełnego skeletonu,
- fixture jest minimalnym dokumentem OpenXML przygotowanym na potrzeby testów,
- brak jeszcze differential testing z oryginalnym filtrem Okapi.

## 2026-10-06 — DOCX: skeleton i nagłówki/stopki

Dodano kolejne testy TDD:
- `test_docx_reader_emits_skeleton_for_document_structure`,
- `test_docx_reader_includes_headers_and_footers`.

RED:
- 2 nowe testy zakończyły się niepowodzeniem; pierwszy wykazał brak zdarzenia skeletonu, drugi brak odczytu nagłówka/stopki.

Implementacja:
- `DocxReader` emituje `Skeleton` jako `DOCUMENT_PART`,
- skeleton rejestruje co najmniej elementy `paragraph` i `table`,
- reader odczytuje pomocnicze części `word/header1.xml` i `word/footer1.xml`.

Podczas GREEN ujawniono błąd cyklu życia `ZipFile`: archiwum było zamykane przed odczytem części pomocniczych. Naprawiono implementację przez odczyt tych części przed zamknięciem archiwum; testów nie zmieniano.

Weryfikacja:
- `tests/test_docx_reference.py` → `5 passed`,
- cały pytest → `13 passed`,
- `compileall` dla `core`, `filter_ir`, `filters`, `analyzer`, `importer`, `differential` → OK.

Backup przed tym etapem:
- `backups/20261006-docx-skeleton/pre-change.tar.gz`
- SHA-256: `65a70a863389b622f498ab619c960746460ba82fc80e9e9b6022a6dc5f3ffa65`


## 2026-10-06 — Rozbudowa fixture'a DOCX i readera

- Utworzono backup przed zmianami: `backups/20261006-docx-expansion/pre-change.tar.gz`.
- SHA-256 backupu: `3a59e91283dce3cb00b8f783e6fb8e2385e36f873d1251a76bc71e9fe517d9ae`.
- Dodano osobny cykl TDD dla rozszerzonego DOCX:
  - wiele runów w jednym akapicie,
  - Unicode: polskie znaki, CJK i emoji,
  - puste runy,
  - zagnieżdżone elementy chronione,
  - metadata stylu akapitu,
  - END_DOCUMENT.
- RED: 5 nowych testów początkowo nie przechodziło.
- Rozszerzono model `TextUnit` o opcjonalne `metadata`.
- Rozbudowano `DocxReader` o metadata stylu `w:pStyle` i wydzieloną obsługę jednostki paragrafu.
- Rozbudowano fixture `fixtures/docx/reference.docx` o przypadki wielorunowe, Unicode, puste elementy, protected content oraz zachowanie wcześniejszych przypadków akapitu i hyperlinku.
- GREEN: 6 nowych testów przechodzi.
- Weryfikacja całego projektu: **19 passed**.
- `compileall` dla aktualnych modułów projektu: **OK**.
- Nie instalowano żadnych pakietów.
- Następny etap: osobny cykl TDD dla writer'a DOCX i testu round-trip.


## 2026-10-07 — Writer DOCX i round-trip

- Utworzono backup przed etapem: `backups/20261006-docx-writer/pre-change.tar.gz`.
- SHA-256: `454f96b5c921470935ecaaa59478720770dcb188ab537bd87af434ed20589dbd`.
- TDD writer'a rozpoczęto od 3 testów RED:
  - utworzenie poprawnego kontenera DOCX,
  - zachowanie inline `Code`,
  - round-trip Unicode/protected/style.
- Dodano `filters/docx/writer.py` bez zewnętrznych zależności.
- Writer obsługuje tekst, `hyperlink`, `protected` oraz metadata stylu akapitu.
- GREEN: 3/3 testy writer'a.
- Pełny zestaw: **22 passed**.
- `compileall`: **OK**.
- Nie instalowano żadnych pakietów.
- Writer jest nadal świadomie minimalny: nie zachowuje jeszcze tabel, header/footer, relacji hyperlinków ani pełnej struktury skeletonu. Jest to zakres kolejnego cyklu rozszerzenia round-trip.

## 2026-10-07 — Strukturalny round-trip DOCX

- Backup etapu: `backups/20261007-continuation/pre-change.tar.gz`.
- SHA-256: `68e7efd7763f2e7a79cc29a01e6810121b03f678163d3f51e297e56f7d000361`.
- TDD: dodano testy tabel, header/footer, relacji hyperlinków, pustego akapitu i kolejności.
- Rozszerzono `Code` o opcjonalny `target`, aby relacja hyperlinku nie była tracona podczas round-trip.
- Reader DOCX zachowuje metadata `container/table/cell`, `part=header|footer|body`, pusty akapit oraz cel hyperlinku odczytany z `.rels`.
- Writer DOCX zapisuje tabele, header/footer, relacje hyperlinków oraz referencje header/footer w `sectPr`.
- RED ujawnił brak obsługi struktur; po implementacji GREEN.
- Weryfikacja: `tests/test_docx_writer.py` → **9 passed**; cały pytest → **28 passed**.
- Nie instalowano pakietów.
- Następny etap: Analyzer JAR.


## 2026-10-07 — Wznowienie po przywróceniu SentinelX i differential core

- Po ponownym uruchomieniu połączenia SentinelX potwierdzono stan hosta `host_74ed00a6b24a48a2` (`agent_version 0.23.1`).
- Pierwsza świeża weryfikacja wykazała 3 oczekujące testy differential; brakujące moduły zostały uzupełnione.
- Dodano `differential/event_normalizer/normalizer.py` oraz `differential/comparator/comparator.py`.
- Differential normalizer zachowuje typ zdarzenia, dataclasses, tuple/list/dict, metadata i target hyperlinku.
- Comparator raportuje różnice pozycyjne i różnice liczby zdarzeń.
- Świeży pełny wynik: **35 passed**.
- Nie instalowano pakietów.
- Kolejny etap: importer Filter IR i generator Python, następnie walidacja na rzeczywistym JAR-ze.


## 2026-10-07 — Importer, generator, class inspector i smoke test Markdown

- Wznowiono pracę bez zatrzymywania procesu między etapami.
- Dodano `analyzer/class_inspector/inspector.py`: bezpieczny odczyt nagłówka classfile i constant pool bez uruchamiania kodu Java.
- Dodano importer extraction oraz IR generation.
- Dodano generator wykonywalnego filtra Python i raport adapterów.
- Dodano differential report.
- Dodano Markdown smoke filter z round-trip Unicode.
- Zweryfikowano rzeczywisty `runtime-markdown-1.49.0-SNAPSHOT.jar` przez importer/class inspector.
- Kompilacja modułów Python: **OK**.
- Świeży pełny wynik: **44 passed**.
- Java jest używana wyłącznie do analiz/oracle; rdzeń Python nie uruchamia JVM.
- Nie instalowano pakietów i nie modyfikowano `tlumacz-v4`.


## 2026-10-07 — Weryfikacja końcowa aktualnego fundamentu

- Dodano CLI `tools/okapi_inspect.py` do read-only inspekcji JAR.
- Pełna kompilacja modułów: **OK**.
- Pełny zestaw testów: **45 passed**.
- Zweryfikowano rzeczywisty JAR Markdown: inspekcja manifestu, 38 klas i entry class.
- Zweryfikowano pipeline extraction → Filter IR → generator Python oraz wykonywalny round-trip wygenerowanego filtra tekstowego.
- Zweryfikowano Markdown smoke round-trip oraz pełny DOCX reader/writer round-trip.
- Ograniczenie oracle: dostarczony zestaw testdata zawiera runtime-markdown i zależności flexmark, ale nie zawiera kompletnego runtime `runtime-common`, dlatego nie wykonano jeszcze rzeczywistego uruchomienia `MarkdownFilter` z JVM. Java pozostaje narzędziem analizy, a nie zależnością produkcyjnego rdzenia.
- To ograniczenie jest jawnie odnotowane i nie jest maskowane testem pozornie differential.
- Nie instalowano pakietów i nie modyfikowano `/home/frs/Projekty/tlumacz-v4`.


## 2026-10-07 — Włączenie pełnych źródeł Okapi-main do analizy

- Potwierdzono dostęp do `/home/frs/Projekty/Okapi-main`.
- Źródła Markdown obejmują `MarkdownFilter`, `MarkdownEventBuilder`, `MarkdownSkeletonWriter`, parser, writer, Parameters oraz rozbudowany oficjalny korpus testowy.
- Rozszerzono Analyzer o `JavaSourceBehaviorExtractor`, który odzyskuje z rzeczywistego źródła Okapi m.in. MIME, rozszerzenia, cechy i klucze parametrów.
- Filter IR rozszerzono o `parameters`.
- Importer przekazuje zachowanie źródłowe do IR dla Markdown.
- Pełny wynik po zmianach: **50 passed**.
- Próba budowania Okapi przez Maven została wykonana, ale system nie ma zainstalowanego `mvn`; nie instalowano go zgodnie z zasadą braku instalacji bez zgody. Repozytorium nie zawiera wrappera Maven.
- Źródło `Okapi-main` pozostaje wyłącznie materiałem referencyjnym; nie modyfikowano go.


## 2026-10-07 — Formalizacja Markdown Filter IR i pierwszy rzeczywisty runtime Python

- Backup przed etapem: `backups/20261007-markdown-ir/pre-change.tar.gz`.
- SHA-256 backupu: `949b4e8e6dc737b755da3ca28f1bc6fb72e485ca229a9dbfca7c3d927af50bc6`.
- Formalny Filter IR rozszerzono o `ParameterRule` i `TokenRule`; walidacja wykrywa duplikaty reguł i niepoprawne strategie tagów.
- Dodano parser JSON IR: `filter_ir/parser/json_parser.py`, normalizator: `filter_ir/normalizer/normalizer.py` oraz schemat `filter_ir/schema/filter-ir.schema.json`.
- `JavaSourceBehaviorExtractor` został rozszerzony z prostego inwentarza cech do ekstrakcji reguł parametrów i tokenów. Dla referencyjnego Markdown odzyskano **17 parametrów** i **14 reguł tokenów** oraz 8 formalnych cech zachowania.
- Importer przekazuje parametry, ich reguły i reguły tokenów do Filter IR.
- Markdown Python Filter nie jest już identity smoke stubem: emituje TextUnits/DocumentParts, rozpoznaje nagłówki/listy, bold/italic, linki z targetem, inline code, obrazy oraz chroni fenced code blocks; zachowuje YAML front matter jako DocumentPart.
- Round-trip na oficjalnym korpusie Okapi Markdown: **60 plików, 0 różnic**.
- Testy Markdown: **4 passed**.
- Testy Filter IR: **7 passed**.
- Testy source extractor: **4 passed**.
- Testy importer pipeline: **6 passed**.
- Świeża pełna weryfikacja: **60 passed in 1.07s**.
- `compileall`: **OK**.
- Schemat JSON został zweryfikowany przez `python3 -m json.tool`.
- Nie instalowano żadnych pakietów. Nie modyfikowano `/home/frs/Projekty/tlumacz-v4` ani `/home/frs/Projekty/Okapi-main`.
- Ograniczenie nadal jawne: Python Markdown runtime jest implementacją opartą o formalizowane reguły zachowania i testy round-trip; pełna zgodność event-for-event z Java Oracle wymaga jeszcze uruchomienia kompletnego oracle, którego lokalne środowisko nadal nie buduje przez brak Maven/runtime dependencies.


## 2026-10-07 — Weryfikacja możliwości uruchomienia Java Oracle

- Potwierdzono lokalny runtime Java: `/usr/lib/jvm/java-27-openjdk/bin/java`, OpenJDK **27**.
- W repozytorium Okapi-main nie znaleziono kompletnego zestawu JAR-ów common; lokalny cache `~/.m2/repository` nie zawiera wymaganych artefaktów Okapi.
- Próba uruchomienia `runtime-markdown-1.49.0-SNAPSHOT.jar` bez zależności zakończyła się przewidywalnie na `NoClassDefFoundError: net/sf/okapi/common/filters/AbstractFilter`.
- Nie instalowano Maven/JDK ani żadnych zależności. Nie pobierano obcych bibliotek do projektu.
- Wniosek: Java runtime istnieje, ale aktualny materiał lokalny nie pozwala jeszcze uruchomić pełnego MarkdownFilter Oracle; ograniczenie pozostaje techniczne i udokumentowane.


## 2026-10-07 — Analiza AbstractFilter/IFilter i kontraktu lifecycle

Potwierdzono w źródłach `/home/frs/Projekty/Okapi-main`, że `AbstractFilter` nie implementuje parsera konkretnego formatu. Jest wspólną warstwą frameworka Okapi nad `IFilter`: lifecycle `open/hasNext/next/close`, parametry, konfiguracje, MIME, tworzenie `START_DOCUMENT`/`END_DOCUMENT`, skeleton writer i filter writer oraz konfiguracja subfiltrów. Właściwe zachowanie Markdown pozostaje w `MarkdownFilter`, `MarkdownParser`, `MarkdownEventBuilder`, `MarkdownSkeletonWriter` i `MarkdownFilterWriter`.

Zidentyfikowano dodatkowo `IFilter` jako formalny kontrakt wspólnego rdzenia. `EventBuilder` jest istotną warstwą realizacji budowania eventów, TextUnit, Code i Skeleton, więc dalsza migracja nie może ograniczać się do parsera Markdown.

Implementacja:
- `SourceBehavior` i `FilterIR` przechowują superclass, lifecycle methods i framework contract.
- importer propaguje te informacje do IR.
- `core/filter.py` otrzymał Okapi-style lifecycle `open()`, `has_next()`, `next()`, `close()`; `run()` korzysta z tego lifecycle i zachowuje dotychczasowy Writer API.
- zachowano rozdział Reader → lifecycle Filter → Writer; nie kopiowano implementacji Java.

TDD:
- RED: test kontraktu frameworka i test lifecycle początkowo nie przechodziły.
- GREEN: minimalna implementacja przeszła testy.
- REFACTOR: usunięto zbędne importy.
- pełna weryfikacja po zmianach: **64 passed**.

Backup etapu:
`backups/20261007-abstract-filter-contract/pre-change.tar.gz`
SHA-256: `0b65fb363c58f80f8c02dd4c38ce68498a71f817d613280b20d2a17c811612aa`


## 2026-10-07 — Weryfikacja CLI i naprawa uruchamiania bez PYTHONPATH

Świeża weryfikacja ujawniła błąd uruchamiania `python3 tools/okapi_inspect.py ...`: skrypt uruchamiany bezpośrednio nie widział pakietu `analyzer`. Dodano test regresyjny uruchamiający CLI jako osobny proces oraz poprawiono `tools/okapi_inspect.py`, aby dodawał katalog repozytorium do `sys.path` przy bezpośrednim uruchomieniu.

Weryfikacja po poprawce:
- test CLI procesu: **1 passed**;
- inspekcja rzeczywistego JAR: **38 klas**, manifest poprawny;
- `compileall`: **OK**;
- pełny pytest: **65 passed**.


## 2026-10-07 — EventBuilder jako część wspólnego rdzenia

Analiza `EventBuilder.java` potwierdziła, że wspólny rdzeń Okapi potrzebuje osobnej warstwy budowania eventów. `EventBuilder` zarządza kolejką eventów, lifecycle TextUnit/DocumentPart, kodami inline, stanem dokumentu oraz kolejnością zasobów. `MarkdownEventBuilder` rozszerza go o MIME Markdown i post-processing `InlineCodeFinder`.

Dodano `core/events/builder.py` jako niezależną reimplementację kontraktu obserwowalnego, bez kopiowania kodu Java. Obsługuje obecnie:
- `start_document()` / `end_document()`;
- `start_text_unit()` / `add_text()` / `add_code()` / `end_text_unit()`;
- `start_document_part()` / `end_document_part()`;
- kolejkę eventów i `has_next()`;
- walidację niedozwolonych przejść lifecycle.

TDD:
- RED: nowy test początkowo nie miał implementacji `EventBuilder`;
- następnie ujawniono błąd samego testu lifecycle i poprawiono test przed implementacją właściwej reguły;
- GREEN: **3 passed** dla EventBuilder;
- pełna regresja: **68 passed**.

To jest kolejny element wspólnego rdzenia. Następnym obszarem implementacji pozostaje rozszerzenie modelu eventów o `START_GROUP`, `END_GROUP`, `START_SUBDOCUMENT`, `END_SUBDOCUMENT`, `START_SUBFILTER`, `END_SUBFILTER` oraz skeleton/group semantics wymagane przez rzeczywiste filtry Okapi.

- 2026-10-07 — Rozszerzenie kontraktu EventBuilder o grupy, subdokumenty i subfiltry: EventType oraz zasoby START/END_GROUP, START/END_SUBDOCUMENT, START/END_SUBFILTER; nested lifecycle, parent IDs i skeleton attachment. TDD: 4 nowe testy, 7 testów EventBuilder PASS; pełna regresja 72 passed.

- 2026-10-07 — Niezależny InlineCodeFinder oraz MarkdownEventBuilder: regexowe reguły inline, domyślna reguła Markdown {{...}}, zachowanie istniejących Code i post-processing TextUnit po wzorcu MarkdownEventBuilder.java. TDD: 3 testy findera + 1 test MarkdownEventBuilder PASS.

- 2026-10-07 — Walidacja PoC Markdown na oficjalnym korpusie Okapi: 58 plików referencyjnych, 58/58 round-trip bez różnic. Dodano regresyjny test całego korpusu. Lokalny Java oracle nadal nie jest uruchamialny: brak kompletnego zestawu JAR zależności; nie instalowano Maven/JDK/dependency.

- 2026-10-07 — Korekta ekstrakcji parametrów Markdown: odfiltrowano pola runtime InlineCodeFinder (sample/useAllRulesWhenTesting) i dodano rzeczywiste klucze translateCodeBlocks, nonTranslateBlocks oraz codeFinderRules. Test źródłowego inwentarza parametrów: PASS; pełna regresja: 78 passed.

- 2026-10-07 — Utworzono `AGENTS.md` przez SentinelX. Dokument definiuje cel projektu, autonomiczny workflow, TDD, zasady referencyjnego użycia Okapi, backupy oraz obowiązek usuwania powstałych plików `.bak`.

- 2026-10-07 — Rozszerzono cel `AGENTS.md`: projekt ma dostarczać również skrypty do automatycznej konwersji filtrów Okapi do niezależnych filtrów Pythonowych.


## 2026-10-07 — Pierwszy automatyczny pipeline konwersji Okapi → Python

Dodano `importer/pipeline.py` oraz CLI `tools/okapi_convert.py`. Pipeline automatycznie wykonuje: inspekcję JAR → ekstrakcję metadanych i zachowania → generowanie Filter IR → generowanie pakietu Python → raport wymaganych adapterów. Dla rzeczywistego `runtime-markdown-1.49.0-SNAPSHOT.jar` wygenerowano `filter.py`, `filter_ir.json`, `conversion_report.json` i `__init__.py`.

TDD: nowy test pipeline'u początkowo RED (`ModuleNotFoundError`), następnie GREEN; dodano test CLI uruchamianego jako osobny proces. Testy automatycznej konwersji: **4 passed**. Pełna regresja zostanie wykonana po zakończeniu refaktoryzacji tego etapu.

Istotne ograniczenie: wygenerowany `filter.py` jest obecnie wykonywalnym szkieletem, a nie pełną automatycznie odtworzoną implementacją parsera. Automatyzacja analizy, IR i pakietowania jest już działająca; kolejnym celem jest zwiększanie zakresu automatycznej generacji zachowania z wykorzystaniem reguł IR i adapterów.


## 2026-10-07 — Generator parametrów filtra z Filter IR

Rozszerzono generator Python o automatyczne tworzenie `parameters.py` na podstawie `ParameterRule` z Filter IR. Nazwy camelCase są konwertowane do snake_case, a typy `boolean/string/integer/pattern` do odpowiednich adnotacji Python. Wygenerowany pakiet eksportuje również klasę parametrów.

TDD: test nowej funkcji najpierw RED (brak `parameters.py`), następnie GREEN po minimalnej implementacji. Testy automatycznej konwersji: **5 passed**.


## 2026-10-07 — Automatyczna analiza filtra OpenXML/DOCX

Rozszerzono `JavaSourceBehaviorExtractor` o analizę `OpenXMLFilter.java` i `ConditionalParameters.java`. Extractor odzyskuje MIME `application/xml`, rozszerzenia dokumentów OpenXML, kontrakt `IFilter`, lifecycle oraz znaczną część cech i parametrów konfiguracyjnych. Rozszerzono również parser domyślnych wartości parametrów o wartości całkowite i proste wyrażenia arytmetyczne, co pozwala odzyskać m.in. `maxAttributeSize = 4 MiB`.

Importer został rozszerzony tak, aby rzeczywisty `runtime-openxml-1.49.0-SNAPSHOT.jar` korzystał z tego kontraktu. Test konwersji OpenXML przechodzi i potwierdza obecność MIME, rozszerzeń, cech oraz parametrów w wygenerowanym Filter IR.

DOCX/OpenXML nadal **nie jest ukończony** jako pełny port filtra: obecny Pythonowy reader/writer jest PoC, a zgodność z bogatym zachowaniem `WordDocument`/`StyledTextPart`/skeleton/relacjami i pozostałymi częściami OpenXML wymaga dalszej implementacji i differential testing.

## 2026-10-07 — Kontynuacja dwóch strumieni: DOCX/OpenXML + automatyczny konwerter
- DOCX reader/writer rozszerzono o zachowanie współrzędnych tabeli (`table`, `row`, `cell`) oraz odtwarzanie wielu wierszy zamiast jednej spłaszczonej wierszowej struktury.
- DOCX reader zachowuje `num_id` i `num_level` z `w:numPr`; writer odtwarza `w:numPr` oraz minimalną część `numbering.xml` i relację pakietu.
- Dodano regresje dla wielowierszowych tabel i numeracji.
- Importer przestał wybierać źródło Java wyłącznie po nazwie filtra: wyszukuje plik źródłowy na podstawie `entry_class` w `Okapi-main` i zapisuje `source_path` w wyniku ekstrakcji.
- Filter IR rozszerzono o `entry_class`; generator zachowuje rzeczywistą nazwę klasy wejściowej Java.
- Generowany adapter zawiera kontrakt metadanych i lifecycle (`open`, `has_next`, `next`, `close`, `round_trip`) zamiast samego stubu `round_trip`.
- Raport konwersji zawiera `entry_class` i `behavior_source`.
- Ograniczenie: generator nie odtwarza jeszcze pełnej semantyki parsera Java; jest wykonywalnym adapterem kontraktowym i punktem wejścia do dalszej automatycznej syntezy zachowania.

## 2026-10-07 — OpenXML: notes/comments/revisions oraz generyczna analiza źródła
- Reader DOCX rozszerzono o `word/footnotes.xml`, `word/endnotes.xml` i `word/comments.xml`; treść jest emitowana jako osobne TextUnits z metadanymi `part`, `note_id`/`comment_id`.
- Reader zachowuje referencje przypisów/końcowych jako `Code` oraz tekst rewizji jako `revision`/`protected` zależnie od rodzaju rewizji.
- Dodano rzeczywiste fixture'y z korpusu testowego Okapi: numeracja, przypisy/końcowe, zagnieżdżone rewizje, instrukcje pól i komentarze.
- Dodano smoke test wybranego korpusu DOCX Okapi; dokumenty przechodzą przez reader bez błędu i z poprawnym lifecycle dokumentu.
- Analyzer otrzymał `extract_generic_filter()`: rozpoznaje klasę, superclass/interfejsy, lifecycle, rozszerzenia i sygnały zachowania; lifecycle jest uzupełniany z klasy bazowej.
- Importer używa generycznego extractora dla filtrów innych niż Markdown/OpenXML. Sprawdzono na rzeczywistym `HtmlFilter` i jego `AbstractMarkupFilter`.
- Świeża pełna regresja: 98 testów przechodzi; `compileall` przechodzi; CLI konwersji HTML i OpenXML przechodzi.


## 2026-10-07 — Stabilizacja testów i bezpośrednie właściwości runów DOCX
- Naprawiono konfigurację pytest przez pythonpath = ["."] dzięki czemu standardowe uruchomienie testów z katalogu projektu nie wymaga ręcznego PYTHONPATH.
- Model TextFragment rozszerzono o opcjonalne metadata, aby zachować formatowanie pojedynczych runów bez mieszania go z metadanymi całego TextUnit.
- DOCX reader rozdziela runy na fragmenty i odzyskuje bezpośrednie w:rPr: bold, italic, underline, strike, hidden, color, size, sizeCs, highlight, vertical alignment, run style i font.
- DOCX writer odtwarza te właściwości w w:rPr; dodano round-trip test formatowania.
- Testy istniejące dostosowano do semantyki wielu fragmentów oraz zachowania pustych akapitów.
- TDD: nowy test właściwości runów był RED, następnie reader GREEN, writer GREEN; reader DOCX 12 passed, writer DOCX 12 passed.
- Świeża pełna regresja po zmianach: 100 passed; compileall: OK; poza katalogiem backups/ brak plików .bak.
- Ograniczenie: zaimplementowane są bezpośrednie właściwości runów; dziedziczenie stylów styles.xml/StyleDefinitions, pełne markup/skeleton oraz złożone zachowania RunParser nadal pozostają do odtworzenia.


## 2026-10-07 — Bytecode analyzer: sygnatury metod classfile
- ClassInspector rozszerzono o MethodInspection: nazwa metody, descriptor JVM i access flags.
- Parser classfile przechodzi przez interfaces, fields, methods i attributes bez uruchamiania kodu Java.
- Poprawiono obsługę LONG/DOUBLE w constant pool.
- TDD: test braku result.methods był RED, następnie GREEN; MarkdownFilter odzyskuje open, next, close i hasNext.


## 2026-10-07 — Reverse-engineering OpenXML: hierarchia stylów runów
- Analiza StyledTextPart, BlockParser, RunParser, RunPropertiesParser, RunBuilder, WordStyleDefinitions i MarkupComponentParser potwierdziła, że Okapi nie traktuje rPr jako płaskiego formatowania.
- Kolejność semantyczna WordStyleDefinitions: document defaults -> paragraph style -> run/character style -> direct run properties.
- Style `basedOn` są rozwijane rekurencyjnie; właściwości późniejszego poziomu nadpisują wcześniejsze, a brak właściwości nie usuwa wartości odziedziczonej.
- Okapi ma osobną semantykę właściwości toggle; nie można jej bezpiecznie redukować do prostego merge słowników.
- RunParser dodatkowo obsługuje hidden/vanish, style inclusion/exclusion, highlight/color filtering, complex fields, nested blocks, tab, line break, no-break hyphen i translatable drawing attributes.
- Model Python `TextFragment` rozszerzono o osobne pole `style`, aby zachować proweniencję/identyfikator stylu niezależnie od bezpośrednich `metadata` runu.
- TDD: nowy test był RED (brak trzeciego pola konstruktora), następnie GREEN: 5 passed.
- Następny krok reverse-engineeringu: odtworzenie `styles.xml`/`basedOn` w Pythonowym modelu stylów oraz przełożenie zasad scalania na testowalny moduł.


## 2026-10-07 — reverse-engineering OpenXML: Word styles.xml / basedOn

- Zbadano referencyjne klasy Okapi: WordStyleDefinitions, WordStyleDefinition, StyleDefinitions.
- Potwierdzono semantykę: docDefaults, style domyślny według w:type, hierarchia w:basedOn, zgodność typu rodzic/dziecko, nadpisywanie właściwości przez kolejne poziomy, jawne wartości toggle false oraz w:link dla character style.
- Dodano filters/docx/styles.py: StyleDefinition, StyleRegistry, parser word/styles.xml, rozwiązywanie basedOn, style domyślne, docDefaults, linked character styles i detekcję cykli.
- DocxReader korzysta z StyleRegistry przy budowie TextFragment; bezpośrednie metadata pozostaje zachowane, a rozwiązany styl trafia do TextFragment.style jako resolved_*.
- Zweryfikowano na rzeczywistym fixtures/docx/okapi/1313-numbering-1.docx.
- TDD: testy dziedziczenia, override, toggle false, default style, niezgodnego typu, cyklu, parsera rzeczywistego XML i linked character style.
- Backup: backups/20261007-style-registry/pre-integration.tar.gz
- SHA-256: 6cdc33d92dc79a7fb34047f97dda746916b4ef952bd40c4972ba4d63c2cb61ad

## 2026-10-07 — reverse-engineering OpenXML: RunProperties / RunParser continuation

- Zbadano referencyjne Okapi: RunProperties, RunProperty, RunPropertyFactory, RunPropertiesParser i RunParser.
- Potwierdzono semantykę toggle WPML: brak w@val oznacza true, jawne 0/false/off/no oznacza false; wartość false musi pozostać informacją o nadpisaniu.
- DocxReader rozszerzono o zachowanie jawnych toggle bold, italic, strike, vanish jako true/false.
- Dodano obsługę markerów w runach: w:tab, w:br, w:noBreakHyphen, w:bookmarkStart, w:bookmarkEnd, w:fldChar, w:instrText.
- Zweryfikowano rzeczywisty fixture 1083-date-and-hyperlink-instructions.docx: zachowane są granice bookmarków i złożonych pól.
- TDD rozszerzono o jawne wartości toggle oraz pola/bookmarki.
- Pełna regresja: 112 passed.
- compileall: OK.


## 2026-10-07 — RunBuilder / MarkupComponentParser / MarkupSkeleton

Wykonano kolejny etap reverse-engineering warstwy OpenXML zgodnie z referencyjnym Okapi.

### Ustalenia
- RunBuilder buforuje tekst niezależnie od markup i flushuje markup jako osobne komponenty run body.
- MarkupComponentParser parsuje elementy strukturalne oraz właściwości blokowe; markup nie jest traktowany jako zwykły tekst.
- MarkupSkeleton przechowuje uporządkowany markup i ma relację parent-resource.
- StyledTextPart rozdziela strukturę dokumentu od treści tłumaczalnej; markup tabel i bloków może pozostać w skeleton/document part.

### Implementacja PoC
- dodano Markup do core/document/model.py;
- TextFragment.parts obsługuje str | Code | Markup;
- Skeleton.parts obsługuje str | Markup;
- dodano filters/docx/markup.py z MarkupComponentParser;
- parser zachowuje nazwę elementu, namespace prefix oraz atrybuty;
- parser buduje uporządkowany skeleton nested XML;
- DocxReader zachowuje wrappery w:ins / w:del jako markup start/end;
- w:proofErr zachowywany jest jako markup empty;
- DocxWriter odtwarza nested markup jako rzeczywiste zagnieżdżone elementy XML;
- dodano testy modelu, parsera, readera i writer round-trip.

### Weryfikacja
- pytest -q: 119 passed
- python3 -m compileall -q core filters importer analyzer differential tools: OK
- .bak poza backups/: brak
- backup przed etapem: backups/20261007-markup-parser/pre-change.tar.gz
- SHA-256: a72fe352757dec0b89f97165b37f749714f2f8afee8970b9fa9cfc2b48513f82

### Ograniczenia
To nadal nie jest pełna implementacja OpenXML Okapi. Nadal wymagają pracy m.in. pełny MarkupComponent model, semantyka MarkupSkeleton względem DocumentPart, complex fields, nested hyperlink/field/bookmark, drawings/text boxes, revisions/comments/notes round-trip oraz differential oracle z Javą.

## 2026-10-07 — pełniejszy model MarkupComponent i relacji skeleton/document part

- Ponownie przeanalizowano referencyjne Okapi `MarkupComponent`, `Markup`, `Run` i `MarkupSkeleton`.
- Potwierdzono rozdzielenie komponentu markup od agregatu `Markup` oraz fakt, że `MarkupSkeleton` jest skeletonem zasobu (`DocumentPart`), a nie tylko listą elementów XML.
- Dodano `core.document.model.MarkupComponent` z identyfikatorem komponentu, `parent_id`, `matches` dla par start/end oraz opcjonalnymi właściwościami.
- Dodano walidację sekwencji komponentów: wykrywanie niedopasowanych zamknięć i niezamkniętych komponentów.
- `MarkupComponentParser.components()` buduje deterministyczne identyfikatory `mc-N`, relacje parent/child i pary start/end oraz waliduje wynik.
- `Skeleton` rozszerzono o `document_part` i `parent_id`, zachowując dotychczasową kompatybilność konstruktora.
- Zachowano dotychczasowy model `Markup` jako reprezentację XML start/end/empty używaną przez reader/writer; `MarkupComponent` jest warstwą strukturalną do dalszego differential IR.
- Dodano testy TDD dla identyfikatorów, parentage, matching start/end, walidacji mismatch oraz tożsamości DocumentPart.

### Weryfikacja
- RED: 3 nowe testy początkowo poprawnie wykazały brak `components()` i `MarkupComponent`.
- GREEN: 20 testów `test_docx_expansion.py` przeszło.
- Pełna świeża regresja: `122 passed in 1.82s`.
- `python3 -m compileall -q core filters importer analyzer differential tools`: OK.
- Poza `backups/` nie znaleziono nowych plików `.bak`.
- Backup: `backups/20261007-markup-component/pre-change.tar.gz`.
- SHA-256: `18de3605de28798586d9e0687fc7677148087025b62d9f4e455ff913a7990dd8`.

### Pozostałe ograniczenia
- `MarkupComponent` nie jest jeszcze pełnym odpowiednikiem wewnętrznego modelu Okapi: brakuje wyspecjalizowanych `StyledStart`, `RunProperties`, `BlockProperties`, `Formula` oraz semantyki `apply(FontMappings)`.
- `MarkupSkeleton` ma już tożsamość zasobu w modelu Python, ale writer nie odtwarza jeszcze pełnej struktury `DocumentPart`/skeleton Okapi.
- Complex fields, nested hyperlink/field/bookmark, drawings/text boxes oraz pełny revisions/comments/notes round-trip nadal wymagają osobnych etapów.


## 2026-10-07 — Markup specialization, complex fields i nested hyperlinks

Kontynuowano reverse-engineering OpenXML po etapie pełniejszego MarkupComponent.

### Specjalizacja MarkupComponent
- dodano jawne role komponentów: generic, block_properties, run_properties, formula;
- zachowano informację styled dla właściwości blokowych zawierających w:pStyle;
- pary start/end zachowują tę samą specjalizację i relację matches;
- parser rozpoznaje m.in. rPr, defRPr, endParaRPr, pPr, tblPr, tcPr, trPr, sectPr, oMath, oMathPara.

### Complex fields
- writer przestał zapisywać field_char i field_instruction jako zwykły tekst;
- field_char jest odtwarzany jako w:fldChar/@w:fldCharType;
- field_instruction jest odtwarzany jako w:instrText;
- dodano poprawne odtwarzanie tab, line_break, no_break_hyphen, bookmark_start i bookmark_end jako elementów OpenXML.

### Nested/multi-run hyperlinks
- Markup otrzymał opcjonalny target dla relacji zewnętrznych;
- wielorunowe hyperlinki nie są już spłaszczane do jednego Code: zachowują wrapper w:hyperlink oraz osobne runy i właściwości;
- obsłużono rekursywne hyperlinki w obrębie hyperlinka;
- writer tworzy relację zewnętrzną na podstawie Markup.target.

### Text boxes / DrawingML
- reader rozpoznaje w:txbxContent wewnątrz w:drawing;
- paragrafy tekstowych pól są emitowane jako osobne TextUnits z metadanymi text_box=true;
- zdublowane reprezentacje DrawingML/VML są deduplikowane po znormalizowanej strukturze XML;
- zweryfikowano rzeczywisty fixture 1341-textbox-with-a-hyperlink.docx, w tym complex field HYPERLINK.

### TDD i weryfikacja
- testy specjalizacji MarkupComponent rozpoczęły się od RED, następnie GREEN;
- test complex fields wykazał błędne zapisywanie fldChar/instrText, następnie writer został poprawiony;
- test wielorunowego hyperlinka rozpoczął się od RED i wymusił zachowanie struktury markup;
- test textbox rozpoczął się od RED, ujawnił również podwójną reprezentację DrawingML/VML i został naprawiony przez deduplikację;
- świeża pełna regresja: 127 passed in 1.28s;
- python3 -m compileall -q core filters importer analyzer differential tools: OK;
- poza backups/ brak plików .bak;
- backup: backups/20261007-markup-specialization/pre-change.tar.gz;
- SHA-256: 69a3f7211a294d158fc82de2eb13aa68d243f8fb90305649cdf638727e72ff19.

### Pozostałe ograniczenia
- text box jest obecnie poprawnie ekstrahowany, ale writer nie odtwarza jeszcze pełnej geometrii DrawingML/VML;
- pełna semantyka RunProperties/BlockProperties/Formula nadal wymaga dalszego modelowania, w tym merge/minify/font mappings;
- complex fields są zachowywane strukturalnie, ale nie ma jeszcze pełnego modelu stanu pola/nested field semantics;
- differential testing z Java oracle nadal jest zablokowany brakiem kompletnego lokalnego runtime/dependency set.


## 2026-10-07 — stan complex fields i semantyka RunProperties

- dodano niezależny parser filters/docx/fields.py dla complex fields; model ComplexField przechowuje instrukcję, wynik oraz pola zagnieżdżone; parser rozróżnia fazy instruction/result i wykrywa niezbilansowane begin/separate/end;
- dodano parse_text_unit_fields() agregujący części wszystkich fragmentów jednego TextUnit, co jest istotne dla pól przecinających granice fragmentów;
- dodano filters/docx/properties.py z RunPropertySet: merge hierarchiczny, minify względem właściwości bazowych oraz mapowanie fontów;
- writer zachowuje jawne false dla toggle run properties (b, i, strike, vanish) przez w:val="false";
- potwierdzono na fixture rzeczywisty przypadek complex field HYPERLINK oraz przypadek pola rozciągającego się na więcej niż jeden paragraph/TextUnit; parser jest świadomie używany na zagregowanym strumieniu, a nie niezależnie na każdym fragmencie;
- TDD: nowy test parsera rozpoczął się od RED (brak modułu), następnie GREEN; test writera rozpoczął się od RED dla jawnego false i został naprawiony;
- świeża regresja: 133 passed in 2.12s; compileall OK; brak .bak poza backups;
- backup: backups/20261007-fields-runproperties/pre-change.tar.gz; SHA-256: d426a0fb47d3bf1cf41a8a93a79fd2da8087a56c8e681787e9ac107e152d5e5d.

### Następny etap
Następny krok to spięcie ComplexField ze strumieniem dokumentu (stan pola pomiędzy TextUnitami), następnie pełne mapowanie RunProperty/font mappings i writer-side minify, a potem round-trip text-box/DrawingML.

## 2026-10-07 — Complex Fields / Nested Fields: stabilizacja modelu

Kontynuowano etap OpenXML **Complex Fields / Nested Fields**.

### Stan implementacji
- `filters/docx/fields.py` utrzymuje strukturalny model `ComplexField` z instrukcją, wynikiem oraz rekurencyjną kolekcją pól zagnieżdżonych.
- Parser `parse_complex_fields()` obsługuje markery `begin` / `separate` / `end`, pola wielorunowe i granice fragmentów `TextUnit`.
- Dodano jawne właściwości modelu:
  - `ComplexField.depth` — maksymalna głębokość drzewa wraz z polem bieżącym;
  - `ComplexField.nested_count` — liczba wszystkich potomnych pól w całym poddrzewie.
- Dzięki temu dalszy pipeline konwersji może kontrolować rzeczywistą złożoność pól bez odtwarzania jej z płaskiej sekwencji `fldChar`.

### TDD
- RED: nowy test dla trójpoziomowego zagnieżdżenia poprawnie zakończył się błędem `AttributeError` dla brakującego `depth`.
- GREEN: dodano minimalne właściwości `depth` i `nested_count` bez zmiany istniejącego parsera.
- Test modułu pól: **7 passed**.
- Świeża pełna regresja: **134 passed in 1.72s**.
- `compileall` dla `core filters importer analyzer differential tools`: **OK**.

### Znaczenie dla automatycznej konwersji
Model pól złożonych ma obecnie strukturę wystarczającą do dalszego generowania adapterów i testów round-trip dla nested fields. Pozostałym krokiem w tym obszarze jest walidacja writer'a na wielopoziomowych polach z rzeczywistego DOCX oraz porównanie struktury przed/po konwersji.

### Java-free
Ten etap nie dodaje żadnej zależności Java/JVM. Parser i model pól działają wyłącznie w Pythonie i na standardowych strukturach modelu dokumentu.

### Uwagi o backupach
Narzędzie bezpiecznej edycji utworzyło automatyczne pliki `.bak` przy tej zmianie. Nie zostały one usunięte automatycznie, ponieważ usuwanie plików jest operacją destrukcyjną i wymaga osobnej zgody operatora.
## 2026-10-07 — Complex Fields: pola przekraczające granice TextUnit

Test na rzeczywistym fixture `1341-textbox-with-a-hyperlink.docx` ujawnił ważną własność formatu: `fldChar begin` i `fldChar end` nie muszą znajdować się w tym samym `TextUnit`. Próba analizowania każdego TextUnit niezależnie kończyła się `ValueError: unclosed complex field`.

### Implementacja
- Dodano `parse_text_units_fields(units)`, który scala strumień fragmentów wielu TextUnitów i przekazuje go do tego samego parsera strukturalnego pól.
- Dzięki temu stan pola może być utrzymany przez granice TextUnit bez zmiany istniejącego modelu `ComplexField`.
- Zweryfikowano rzeczywisty dokument `1341-textbox-with-a-hyperlink.docx`: **3 TextUnits**, **1 pole HYPERLINK**, poprawne zakończenie parsera.

### TDD / regresja
- RED: test rzeczywistego fixture'a zakończył się `ImportError` dla brakującego `parse_text_units_fields`.
- GREEN: minimalna funkcja strumieniująca została dodana.
- Testy `test_docx_fields_properties.py`: **8 passed**.
- Świeża pełna regresja: **135 passed in 3.58s**.

### Wniosek architektoniczny
Parser pól nie może być traktowany wyłącznie jako funkcja lokalna dla pojedynczego TextUnit. Dla pełnej zgodności z OpenXML potrzebny jest stan pola na poziomie strumienia dokumentu. Obecna funkcja stanowi minimalny krok w tym kierunku; kolejnym etapem jest spięcie tego stanu bezpośrednio z lifecycle readera/eventów oraz writer-side round-trip dla pól wielopoziomowych.
## 2026-10-07 — ComplexFieldStream: stan pola na poziomie strumienia eventów

Po teście rzeczywistego DOCX potwierdzono, że samo spłaszczanie wszystkich TextUnitów jest rozwiązaniem pomocniczym, ale docelowy model powinien utrzymywać stan pola w czasie przetwarzania strumienia.

### Implementacja
- Dodano `ComplexFieldStream` z metodami `feed()` i `finish()`.
- `begin` otwiera poziom pola, `separate` przełącza stan na wynik, a `end` zamyka bieżący poziom.
- Zagnieżdżone pola pozostają w strukturze `nested` rodzica.
- Pole główne jest publikowane dopiero po zamknięciu jego ostatniego poziomu; przed `finish()` nie jest zgłaszane jako kompletne.
- `parse_complex_fields()` i `parse_text_units_fields()` korzystają teraz ze wspólnego mechanizmu strumieniowego.

### TDD / weryfikacja
- Istniejący test `ComplexFieldStream` był RED z powodu braku klasy.
- Po implementacji: `tests/test_docx_fields_properties.py` → **9 passed**.
- Świeża pełna regresja → **136 passed in 1.30s**.
- `compileall` → **OK**.
- Rzeczywisty fixture `1341-textbox-with-a-hyperlink.docx` został przeanalizowany bez błędu zamknięcia pola.

### Kontrola zależności Java
- `pyproject.toml` nie deklaruje żadnych zależności Java/JVM ani bindingów typu JPype/JNI.
- Produkcyjny kod Python nie zawiera wywołań `subprocess`, `os.system` ani bezpośredniego uruchamiania JVM.
- Referencje `.jar`/Java pozostają w warstwie **Analyzer/importer/testdata/oracle**, czyli w narzędziach migracyjnych, a nie w runtime konwersji dokumentu.
- To potwierdza, że **docelowy runtime filtra jest architektonicznie Java-free**; do zamknięcia pozostaje jeszcze formalny test pakietu produkcyjnego w środowisku bez Javy oraz pełna weryfikacja wszystkich generatorów/adapterów.

### Następny etap
1. Writer-side round-trip dla `ComplexFieldStream` z co najmniej dwoma poziomami zagnieżdżenia.
2. Włączenie `ComplexFieldStream` bezpośrednio do lifecycle `DocxReader`/event stream zamiast analizy post-hoc.
3. Następnie `RunProperties`/font mappings i pełniejszy skeleton/document-part round-trip.

## 2026-10-07 — Complex Fields stream + RunFonts parity

- dodano `ComplexFieldStream`, który utrzymuje stack pól pomiędzy kolejnymi porcjami `Part`, więc `begin`/`separate`/`end` mogą przekraczać granice TextUnit/paragraph;
- streaming zachowuje nested fields jako osobne poddrzewa `ComplexField` i nie miesza ich tokenów z wynikiem pola nadrzędnego;
- dodano `parse_event_stream_fields(events)` jako nieinwazyjny adapter dokumentowego strumienia zdarzeń do parsera pól; istniejący kontrakt `DocxReader` pozostaje kompatybilny;
- RED: test streamingu zwrócił `ImportError` dla brakującego `ComplexFieldStream`; GREEN: minimalna implementacja; test modułu pól: 9 passed;
- przeanalizowano referencyjne `RunPropertyFactory.java` i `RunFonts.java`; rozszerzono reader/writer o kategorie `ascii`, `hAnsi`, `cs`, `eastAsia`, `asciiTheme`, `hAnsiTheme`, `cstheme`, `eastAsiaTheme`, `hint`;
- zachowano kompatybilność historycznego klucza `font`; pojedyncza wartość fontu pozostaje zwarta, a wielokategoriowe `rFonts` są zachowywane bez utraty informacji;
- RED: test pełnego mapowania fontów wykazał utratę kategorii po readerze oraz brak `rFonts` po writerze; GREEN: reader/writer zachowują pełne kategorie; test modułu: 11 passed;
- pełna regresja po zmianach: **138 passed in 1.13s**;
- `python3 -m compileall -q core filters importer analyzer differential tools`: **OK**;
- luźne historyczne `.bak` przeniesiono do `backups/legacy-stray-bak/`; źródła projektu pozostają bez plików `.bak` poza `backups/`;
- backup etapu: `backups/20261007-complex-field-stream/pre-change.tar.gz`;
- backupy RunFonts: `backups/20261007-runfonts/`;

### Następny etap
- writer-side minify z wykorzystaniem rozdzielenia właściwości bezpośrednich od resolved/base;
- round-trip TextBox/DrawingML z zachowaniem struktury `w:drawing` / `w:txbxContent`;
- testy wielopoziomowych pól na rzeczywistych fixture'ach przed/po writerze;
- dalsze domknięcie differential Java oracle i automatycznej konwersji.

### Tryb pracy narzędziowej
W bieżącym etapie zastosowano TDD RED→GREEN, reverse engineering referencyjnego Okapi oraz SentinelX do kontroli repozytorium. Flower nie jest używany do implementacji, ponieważ bieżący kod produkcyjny jest Python/OpenXML i nie wprowadza zmian w Java runtime. Prototype nie był potrzebny: model streamingu wynika bezpośrednio z istniejącego kontraktu i fixture'ów. Short Circuit/Agent Parley pozostają trybem organizacji pracy; w tej sesji nie ma osobnych agentów/worktree wymagających koordynacji.

## 2026-10-07 — 3 etapy: writer minify + TextBox round-trip + nested complex fields

Wykonano bez zatrzymywania trzy kolejne etapy zapisane w poprzednim statusie.

### 1. Writer-side minify / direct vs resolved
- writer jawnie traktuje TextFragment.metadata jako warstwę direct rPr;
- klucze resolved_* są informacją diagnostyczną/base z readera i nie są emitowane jako bezpośrednie w:rPr;
- test potwierdza, że przy direct bold=true oraz resolved_bold=true/resolved_color=000000 writer emituje tylko w:b, bez sztucznego w:color;
- po ponownym readerze zachowana zostaje wyłącznie warstwa direct.

### 2. TextBox / DrawingML round-trip
- writer rozpoznaje grupę kolejnych TextUnitów z metadata.text_box=true;
- odtwarza strukturę w:drawing → wp:inline → a:graphic → a:graphicData → wps:wsp → wps:txbx → w:txbxContent;
- wiele akapitów TextBoxa pozostaje osobnymi w:p wewnątrz w:txbxContent;
- fixture 1341-textbox-with-a-hyperlink.docx przechodzi round-trip strukturalny, a pole HYPERLINK pozostaje wykrywalne po ponownym odczycie;
- ograniczenie: geometria i pełne właściwości wizualne oryginalnego DrawingML nie są jeszcze odtwarzane 1:1; obecny etap zapewnia strukturę kontenera i treść.

### 3. Wielopoziomowe complex fields przed/po writerze
- dodano test round-trip dla zagnieżdżonego IF → PAGE rozdzielonego na dwa TextUnity;
- writer zachowuje liniowy strumień begin/instruction/separate/result/end, a reader + ComplexFieldStream rekonstruują drzewo nested fields;
- fixture rzeczywisty TextBox/HYPERLINK również zachowuje pole przekraczające granicę akapitów.

### TDD / weryfikacja
- RED: nowy test TextBox round-trip początkowo nie znalazł w:drawing, potwierdzając brak implementacji writer-side;
- GREEN: minimalna rekonstrukcja kontenera DrawingML została dodana;
- po GREEN: test modułu DOCX fields/properties 15 passed;
- pełna regresja po trzech etapach: 142 passed in 1.23s;
- python3 -m compileall -q core filters importer analyzer differential tools: OK;
- brak luźnych .bak poza backups/.

### Backup
backups/20261007-three-stages/pre-change.tar.gz oraz automatyczne backupy plików zmian znajdują się w backups/20261007-three-stages/.

### Następny krok
Kontynuować automatycznie: pełniejsze zachowanie właściwości DrawingML/VML TextBoxa, integracja ComplexFieldStream bezpośrednio w lifecycle readera oraz differential/round-trip na szerszym korpusie DOCX; równolegle domykać generator automatycznej konwersji.


## 2026-10-07 — TextBox geometry i właściwości wizualne DrawingML

Rozszerzono writer DOCX na podstawie rzeczywistej struktury fixture 1341-textbox-with-a-hyperlink.docx.

### Zachowane elementy DrawingML
- wp:anchor zamiast wcześniejszego uproszczonego wp:inline;
- marginesy anchor: distT/distB/distL/distR;
- simplePos;
- pozycjonowanie positionH/positionV i posOffset;
- extent z szerokością/wysokością;
- effectExtent;
- wrapNone;
- docPr;
- cNvGraphicFramePr + a:graphicFrameLocks;
- wps:cNvSpPr, a:spLocks;
- wps:spPr + bwMode;
- a:xfrm, a:off, a:ext;
- a:prstGeom (rect);
- a:noFill;
- a:ln, a:noFill, a:miter, a:headEnd, a:tailEnd;
- wps:bodyPr: rotacja, orientacja, wrapping, insety i anchor;
- a:noAutofit.

### TDD
RED został wykonany na oczekiwanej geometrii: writer generował wcześniej wp:inline, więc test wymagający wp:anchor nie przeszedł. Następnie wprowadzono minimalną rekonstrukcję anchor/DrawingML i test przeszedł GREEN.

### Weryfikacja
- test geometrii/właściwości TextBox: 1 passed;
- pełna regresja: 143 passed in 1.38s;
- compileall: OK;
- backupy zmian przeniesione do backups/20261007-three-stages/;
- brak .bak pozostawionych poza backups/.

### Pozostała różnica
To jest już istotnie dokładniejsza rekonstrukcja DrawingML, ale nie należy jeszcze deklarować bit-perfect round-trip. Do pełnego zachowania trzeba jeszcze przenieść z readera do IR wszystkie zmienne właściwości konkretnego obiektu zamiast używania wartości fixture jako stałych, a także obsłużyć równoległy w:pict/v:shape fallback VML oraz relacje/identyfikatory i warianty wrap/position.

## 2026-10-07 — trzy kolejne kroki bez pauzy: TextBox dynamiczny, ComplexField lifecycle, korpus DOCX

### Krok 1 — dynamiczne DrawingML/VML TextBox
- Reader zapisuje źródłowe kontenery wp:anchor i v:shape jako serializowane template’y w metadata TextUnit (textbox_drawingml, textbox_vml).
- Zachowywane są zmienne atrybuty geometrii, pozycji, wrap, transformacji, fill/line, insetów, ID oraz dodatkowe rozszerzenia namespace, zamiast stałych wartości z jednego fixture’a.
- Writer odtwarza template i wymienia wyłącznie w:txbxContent; gdy źródło ma VML fallback, zapisuje również w:pict/v:shape.

### Krok 2 — ComplexFieldStream w lifecycle Readera
- DocxReader utrzymuje jeden ComplexFieldStream przez cały odczyt, więc pola mogą przekraczać granice paragraph/TextUnit.
- Wynik jest dostępny przez DocxReader.complex_fields bez zmiany istniejącego kontraktu eventów.
- Usunięto zduplikowaną definicję ComplexFieldStream; pozostała jedna implementacja kanoniczna z obsługą nested fields i walidacją stanu końcowego.

### Krok 3 — szerszy korpus round-trip
- Dodano test obejmujący cały aktualny korpus 7 plików DOCX w fixtures/docx/**.
- Writer rozszerzono o footnotes/endnotes/comments oraz referencje footnoteReference/endnoteReference.
- Weryfikowane są tekst oraz struktura instrukcji complex fields po write → read.

### TDD / weryfikacja
- nowe testy najpierw RED: brak template metadata, brak lifecycle API oraz utrata notatek/referencji.
- GREEN po minimalnych zmianach: test template’ów, lifecycle oraz korpusu przechodzą.
- pełna regresja: 146 passed in 1.22s.
- python3 -m compileall -q core filters importer analyzer differential tools: OK.

## 2026-10-07 — TextBox fallback: pełna geometria i wizualne właściwości

Kontynuowano etap TextBox bez zmiany globalnej konfiguracji Git; problem `git dubious ownership` został ominięty przez pracę bezpośrednio na plikach i testach SentinelX.

### Implementacja
- rozszerzono fallback writer'a dla TextBox bez źródłowego template'u DrawingML;
- dodano `wp:anchor` z marginesami, `relativeHeight`, `anchorId/editId`, `positionH/positionV`, `posOffset`, `extent`, `effectExtent`, `wrapNone` i `docPr`;
- dodano `cNvGraphicFramePr`, `graphicFrameLocks`, `wps:spPr`, `a:xfrm`, `a:prstGeom`, `a:noFill`, `a:ln` oraz `wps:bodyPr` z insetami, orientacją i anchorem;
- fallback generuje również VML `v:shape` z geometrią i pozycjonowaniem, aby nie wracać do niepozycjonowanego domyślnego pola.

### TDD / weryfikacja
- RED: nowy test wykazał brak `positionH/positionV` w dotychczasowym fallbacku;
- GREEN: rozszerzono minimalnie fallback DrawingML/VML;
- test TextBox geometry/templates: **2 passed**;
- pełna regresja: **147 passed in 1.60s**;
- `python -m compileall -q core filters importer analyzer differential tools`: **OK**;
- dodatkowe porównanie fixture → round-trip potwierdziło identyczność struktury anchor i VML poza `w:txbxContent`, który jest celowo przebudowywany przez writer.

### Uwaga
- Git nadal nie został konfigurowany przez `safe.directory`; nie wykonano żadnej zmiany globalnej konfiguracji.
- Nie instalowano ani nie usuwano pakietów.

## 2026-10-07 — TextBox VML fallback i tożsamość reprezentacji

### Naprawa blocker'a
- Reverse engineering ścieżki writer'a wykazał, że fallback tworzył `v:shape`, ale dodawał go do `w:pict` tylko dla `vml_meta`; bez template'u obiekt był budowany i następnie gubiony.
- Minimalna poprawka przeniosła `pict.append(shape)` poza warunek `if vml_meta`, dzięki czemu fallback rzeczywiście emituje `v:shape`.
- Test `test_textbox_fallback_emits_complete_geometry_and_visual_containers`: GREEN.

### Tożsamość TextBoxów
- Zidentyfikowano drugi błąd: deduplikacja readera oparta wyłącznie na podpisie XML/textu scalała niezależne TextBoxy o identycznej treści.
- Dodano TDD test z dwoma niezależnymi DrawingML TextBoxami o identycznej treści, ale innym `anchorId` i położeniu. RED: 2 zamiast oczekiwanych 4 jednostek.
- Reader otrzymał grupowanie reprezentacji DrawingML/VML przez stabilny `anchorId` oraz deduplikację na poziomie `(container identity, paragraph index)`. Dzięki temu VML/DrawingML tego samego TextBoxa pozostają jedną reprezentacją, a dwa niezależne TextBoxy nie są scalane.

### Weryfikacja
- test fallback VML: **1 passed**;
- test dwóch identycznych TextBoxów: **1 passed**;
- test ekstrakcji istniejącego TextBox fixture: **1 passed**;
- pełna regresja: **148 passed in 2.51s**;
- `python -m compileall -q core analyzer filter_ir importer differential filters tests tools`: **OK**.

### Reverse-engineering evidence
- fixture `fixtures/docx/okapi/1341-textbox-with-a-hyperlink.docx` zawiera równoległe reprezentacje `wp:anchor` i `v:shape` ze wspólnym `anchorId=7F96FC78`; oba zawierają identyczne dwa akapity TextBoxa.
- niezależna kopia `wp:anchor` ze zmienionym `anchorId` i `positionH/posOffset` jest traktowana jako osobny kontener.
- nie zmieniano globalnego Git `safe.directory`; nie instalowano pakietów.


## 2026-10-07 — Automatyzacja konwersji: rozdzielenie źródła zachowania od kontraktu

- Backup etapu: `backups/20261007-automatic-converter-next/pre-change.tar.gz`.
- Generator Python otrzymał jawny wybór strategii implementacji po `entry_class`.
- `MarkdownFilter` jest generowany jako adapter do istniejącej niezależnej implementacji Python, dzięki czemu wygenerowany filtr wykonuje rzeczywiste rozpoznawanie Markdown zamiast identity round-trip.
- Pozostałe filtry bez implementacji Python pozostają oznaczone jako `contract-adapter`; nie są już raportowane jako `source`, ponieważ sama analiza źródła Java nie oznacza automatycznego odtworzenia semantyki.
- Raport `conversion_report.json` rozróżnia obecnie `native-python` i `contract-adapter`.
- Dodano test dowodzący, że wygenerowany Markdown rozpoznaje `bold` jako strukturalny `Code`, oraz test raportu strategii.
- Testy automatycznej konwersji + importer: **20 passed**.
- Następny etap: automatyczna synteza implementacji `rule-generated` z Filter IR (reguły tokenów, parametrów i cech) oraz system adapterów dla filtrów wymagających usług wspólnych Okapi.


## 2026-10-07 — Automatyzacja konwersji: pierwszy generator zachowania z Filter IR

- Rozszerzono generator o trzecią strategię `rule-generated`.
- Dla `TokenRule` generator potrafi obecnie syntezować prosty parser/writer dla reguł paired: `STRONG_EMPHASIS`, `EMPHASIS` i `CODE`.
- Wygenerowany filtr produkuje rzeczywiste `Event`/`TextUnit`/`Code`, zamiast zwracać wejściowy tekst jako identity adapter.
- Strategia jest dobierana w kolejności: `native-python` → `rule-generated` → `contract-adapter`.
- Raport konwersji zachowuje wybraną strategię, dzięki czemu wynik można automatycznie kwalifikować do dalszego differential testingu zamiast traktować każdy wygenerowany pakiet jako pełny port.
- TDD: test generatora regułowego rozpoczął się RED z brakiem `read()`, następnie GREEN; dodano także test jawnego raportowania `rule-generated`.
- Testy automatycznej konwersji + importer: **22 passed**.
- Pełna regresja projektu: **156 passed**.
- `compileall`: **OK**.
- Następny zakres: rozszerzanie mapowania reguł IR o `isolated`, `document_part`, protected content, parametry wpływające na parser oraz automatyczne wykrywanie zależności wspólnego runtime Okapi.


## 2026-10-07 — Kwalifikacja automatycznej konwersji bez ingerencji w tłumaczenie

- Zakres pozostaje wyłącznie automatyzacją konwersji Okapi → Python; nie zmieniano procesu tworzenia ani wykonywania tłumaczenia.
- Generator nie kwalifikuje już automatycznie każdej obecności `TokenRule` jako `rule-generated`.
- `rule-generated` jest dostępne tylko wtedy, gdy wszystkie reguły tokenów mieszczą się w aktualnie obsługiwanym podzbiorze (`paired`: `STRONG_EMPHASIS`, `EMPHASIS`, `CODE`).
- Reguły `isolated`, `document_part`, `text` oraz nieobsługiwane typy są jawnie raportowane jako `unsupported_token_rules`, a filtr pozostaje `contract-adapter` do czasu rozszerzenia generatora.
- Dzięki temu automatyzacja nie produkuje pozornie kompletnego filtra na podstawie częściowej semantyki.
- Test RED→GREEN dla kwalifikatora: **1 failed → 3 passed** po minimalnej zmianie.


## 2026-10-07 — Automatyzacja konwersji katalogu filtrów

- Rozszerzono `OkapiConversionPipeline` o `convert_catalog()`, który automatycznie wykrywa `filter.json` oraz odpowiadający `runtime-{filter}-*.jar` dla całego katalogu filtrów.
- Rozszerzono `tools/okapi_convert.py` o tryb `--catalog` bez zmiany istniejącego trybu pojedynczego JAR-a.
- Batch conversion zweryfikowano na 9 rzeczywistych filtrach: `epub`, `html`, `json`, `markdown`, `openoffice`, `openxml`, `xliff`, `xliff2`, `yaml` — wszystkie zostały wygenerowane bez uruchamiania JVM przez generator.
- Wynik semantyczny jest jawnie raportowany: Markdown używa `native-python`, pozostałe obecnie `contract-adapter`; pipeline nie udaje pełnej implementacji zachowania Java.
- TDD: test batch API RED → implementacja → GREEN; test CLI batch RED → implementacja → GREEN.
- Weryfikacja automatyzacji: **18 passed**; pełny zestaw projektu: **159 passed**.
- Nie instalowano pakietów.


## 2026-10-07 — Raportowanie pokrycia automatycznej syntezy

- Zakres nadal ograniczony do automatyzacji konwersji Okapi → Python; proces tłumaczenia nie był modyfikowany.
- Raport conversion_report.json otrzymał token_rule_coverage (supported, total, ratio), aby mierzyć rzeczywisty zakres reguł tokenów podlegających automatycznej syntezie.
- Raport otrzymał unsupported_features; obecnie znane bezpiecznie kwalifikowane cechy to protected, tables, inline_code i text.
- isolated, document_part, text jako strategie tokenów oraz subfilter jako cecha pozostają jawnie poza generowaniem semantyki i powodują kwalifikację do dalszego adaptera zamiast pozornego pełnego portu.
- TDD: nowe testy pokrycia i nieobsługiwanych cech: RED (2 failed z brakującymi polami) → GREEN (2 passed); pełny moduł automatycznej konwersji: 20 passed.
- Pełna regresja projektu: 165 passed in 1.83s; compileall: OK; pliki .bak poza backups/: 0.
- Backup przed zmianą: backups/20261007-143608-automation-next/pre-change.tar.gz.
- Zmieniono konfigurację Git użytkownika tylko w zakresie uzgodnionym przez użytkownika: dodano repozytorium do safe.directory, bez użycia sudo.
- Następny etap pozostaje reverse-engineeringiem semantyki kolejnych reguł/cech; nie będą one implementowane bez wystarczających dowodów zachowania.


## 2026-10-07 — Pierwszy natywny port strukturalnego filtra YAML bez Javy

- Zakres tej sesji został rozdzielony od automatyzacji katalogu: rozwijany jest **sposób semantycznego portowania filtra do runtime Python**, bez ingerencji w proces tłumaczenia.
- Dodano `filters/yaml/filter.py` jako natywną implementację YAML bez JVM.
- Zastosowano wzorzec **structural parser + lossless source spans**: PyYAML służy do ustalenia struktury map/sekwencji i scalarów, natomiast oryginalny dokument pozostaje skeletonem.
- Klucze YAML nie są emitowane jako TextUnit; wartości scalar są identyfikowane ścieżką `yaml_path`, a każdy TextUnit zachowuje dokładne `source_start/source_end`, styl scalaru i oryginalny fragment.
- Writer nie wykonuje ponownej serializacji YAML. Przy zmianie tłumaczenia podmienia wyłącznie odpowiadający zakres źródła, dzięki czemu komentarze, kolejność, separatory i pozostała składnia pozostają nietknięte.
- Obsłużono wartości plain, single-quoted, double-quoted oraz literal/folded block na poziomie zachowania struktury i stylu.
- TDD: testy natywnego filtra rozpoczęły się od RED z brakiem implementacji; następnie GREEN. Rozszerzone przypadki cytowania i bloków również przeszły cykl RED → poprawka → GREEN.
- Testy YAML native: **6 passed**.
- Pełna regresja projektu po zmianie: **167 passed**.
- `compileall` dla `filters/yaml`, `core`, `importer`, `filter_ir`, `analyzer`, `differential`, `tests`: **OK**.
- Nie instalowano pakietów i nie uruchamiano JVM podczas testów natywnego filtra.
- Wniosek dla dalszych portów: dla formatów strukturalnych preferowany jest model **parser AST → translatable spans → immutable skeleton → span-aware writer**, zamiast translacji kodu Java 1:1.
- Następny kandydat do tego samego sposobu portowania: JSON, następnie HTML/XML; filtry DOCX/OpenXML pozostają osobnym, natywnym torem.


## 2026-10-07 — Generyczne odzyskiwanie kontraktu parametrów z Java

- Zakres: automatyzacja konwersji filtrów Okapi → Python; bez ingerencji w proces tłumaczenia.
- `JavaSourceBehaviorExtractor.extract_generic_filter()` odzyskuje teraz kontrakt parametrów z sąsiedniego `Parameters.java` dla filtrów bez dedykowanego extractora.
- Rozpoznawane są akcesory `getX`, `isX`, `shouldX` oraz `setX` dla typów boolean/String/int/long/double/float.
- Wartości domyślne nie są zgadywane: dla generycznych parametrów pozostają `None`, dopóki nie ma bezpośredniego dowodu w źródle.
- TDD: nowy test najpierw RED (`StopIteration` dla `extractStandalone`), następnie minimalna implementacja → GREEN; rozszerzenie o `shouldX` również zweryfikowano przez RED → GREEN.
- Weryfikacja: `tests/test_source_extractor.py` + `tests/test_automatic_conversion.py` — **27 passed**.
- Batch smoke conversion potwierdził odzyskanie parametrów: HTML 1, JSON 19, YAML 12, OpenOffice 5, XLIFF 49, XLIFF2 1; Markdown/OpenXML nadal korzystają z dedykowanych extractorów.
- Backup: `backups/20261007-1550-generic-parameter-contract/pre-change.tar.gz`.
- Nie instalowano pakietów i nie uruchamiano JVM.

## 2026-10-07 — DOCX: domknięcie semantyki rewizji, core properties i metadanych graficznych

Native DOCX został rozszerzony w kierunku zgodności zachowania z Okapi OpenXMLFilter:

- `w:ins` jest traktowane zgodnie z domyślnym `automaticallyAcceptRevisions=true`: wrapper rewizji nie jest emitowany jako kod, a zawartość pozostaje tekstem tłumaczalnym.
- `w:del` jest pomijane jako usunięta rewizja.
- obsługiwane są translowalne Word core properties zgodnie z `wordDocPropertiesConfiguration.yml`: `dc:title`, `dc:subject`, `dc:creator`, `dc:description`, `cp:category`, `cp:contentStatus`, `cp:keywords`; `cp:lastModifiedBy` pozostaje nietłumaczone.
- `wp:docPr/@name`, `pic:cNvPr/@name` oraz `v:textpath/@string` są modelowane jako translowalne atrybuty źródłowe.
- writer modyfikuje te atrybuty bez przebudowy pakietu DOCX.
- writer nadal pracuje na oryginalnym ZIP i zachowuje nietranslowane części pakietu.
- dodano regresję dla TextBoxów DrawingML/VML, header/footer oraz core properties.

Weryfikacja: `86 passed` w `tests/test_docx*`; `compileall` dla `filters/docx` i `core` przechodzi.

### 2026-10-07 — DOCX: hidden text semantics + Java Okapi validation

- Native DOCX reader now follows Okapi's default `translateWordHidden=false` behavior: runs hidden by `w:vanish`, including visibility inherited through resolved paragraph/character styles, are excluded from translatable text.
- `DocxReader(translate_word_hidden=True)` enables extraction of hidden run text, matching Okapi's explicit option.
- Hyperlink runs use the same resolved visibility semantics.
- Added regression tests for default hidden-text exclusion and explicit inclusion.
- Local Okapi Java/OpenXML reference is now executable with Maven. The complete `OpenXMLTest` class passed: 85 tests, 0 failures, 1 skipped.
- A full Okapi reactor test run still has one unrelated `okapi-core` failure on JDK 27 in `StringSanitiserTest.failsWithDoubleParsingFilter`; this does not affect the OpenXML module.
- Native project suite: 180 passed; `compileall` passes.

### 2026-10-07 — DOCX: numbering level text

- Added optional `translate_word_numbering_level_text=True` to native reader.
- Referenced `w:lvlText` definitions are emitted as dedicated `part=numbering` text units.
- `%1`..`%9` level-number placeholders are represented as protected `level_number` codes, matching Okapi's `x-level-number;` placeholder semantics at the IR boundary.
- Native writer patches the original `word/numbering.xml` `w:lvlText/@w:val`, including `w:lvlOverride`, without reconstructing the numbering part.
- Verified a real Okapi `1313-numbering-1.docx` read/modify/write round-trip.
- Native project suite: 182 passed; `compileall` passes.
