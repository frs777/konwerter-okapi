from __future__ import annotations

from dataclasses import dataclass
import json

from core.document.model import TextFragment, TextUnit
from core.events.model import Event, EventType


@dataclass(frozen=True, slots=True)
class _StringSpan:
    start: int
    end: int
    path: str
    name: str


class JsonFilter:
    """Java-free JSON filter using a recursive parser and lossless source spans.

    Only JSON string values are translatable. The original source remains the
    skeleton; writing replaces only the corresponding JSON string token.
    """

    def read(self, source: str):
        decoder = json.JSONDecoder()
        spans: list[_StringSpan] = []
        position = self._parse_value(source, 0, "", spans, decoder)
        position = self._skip_whitespace(source, position)
        if position != len(source):
            raise ValueError(f"unexpected JSON data at position {position}")

        events = [Event(EventType.START_DOCUMENT, source)]
        for index, span in enumerate(spans, start=1):
            raw = source[span.start:span.end]
            value = json.loads(raw)
            unit = TextUnit(
                id=f"json-{index}",
                fragments=(TextFragment((value,)),),
                metadata={
                    "json_path": span.path,
                    "name": span.name,
                    "source_start": str(span.start),
                    "source_end": str(span.end),
                    "original": raw,
                },
            )
            events.append(Event(EventType.TEXT_UNIT, unit))
        events.append(Event(EventType.END_DOCUMENT, None))
        return tuple(events)

    def write(self, events) -> str:
        source = next(
            (event.resource for event in events if event.type is EventType.START_DOCUMENT),
            None,
        )
        if not isinstance(source, str):
            raise ValueError("JSON write requires START_DOCUMENT with source text")

        replacements: list[tuple[int, int, str]] = []
        for event in events:
            if event.type is not EventType.TEXT_UNIT:
                continue
            unit = event.resource
            metadata = unit.metadata or {}
            if "source_start" not in metadata or "source_end" not in metadata:
                continue
            value = "".join(
                part if isinstance(part, str) else getattr(part, "data", str(part))
                for fragment in unit.fragments
                for part in fragment.parts
            )
            original = metadata.get("original", "")
            if value == json.loads(original):
                continue
            replacements.append(
                (int(metadata["source_start"]), int(metadata["source_end"]), json.dumps(value, ensure_ascii=False))
            )

        result = source
        for start, end, replacement in sorted(replacements, reverse=True):
            result = result[:start] + replacement + result[end:]
        return result

    def round_trip(self, source: str) -> str:
        return self.write(self.read(source))

    def _parse_value(self, source: str, position: int, path: str, spans: list[_StringSpan], decoder: json.JSONDecoder) -> int:
        position = self._skip_whitespace(source, position)
        if position >= len(source):
            raise ValueError("unexpected end of JSON")
        char = source[position]
        if char == '{':
            return self._parse_object(source, position, path, spans, decoder)
        if char == '[':
            return self._parse_array(source, position, path, spans, decoder)
        if char == '"':
            _, end = decoder.raw_decode(source, position)
            spans.append(_StringSpan(position, end, path, path.rsplit('/', 1)[-1] if path else ""))
            return end
        _, end = decoder.raw_decode(source, position)
        return end

    def _parse_object(self, source: str, position: int, path: str, spans: list[_StringSpan], decoder: json.JSONDecoder) -> int:
        position = self._skip_whitespace(source, position + 1)
        if position < len(source) and source[position] == '}':
            return position + 1
        while True:
            if position >= len(source) or source[position] != '"':
                raise ValueError(f"expected JSON object key at position {position}")
            key, position = decoder.raw_decode(source, position)
            position = self._skip_whitespace(source, position)
            if position >= len(source) or source[position] != ':':
                raise ValueError(f"expected ':' after JSON key at position {position}")
            child_path = f"{path}/{key}" if path else f"/{key}"
            position = self._parse_value(source, position + 1, child_path, spans, decoder)
            position = self._skip_whitespace(source, position)
            if position < len(source) and source[position] == '}':
                return position + 1
            if position >= len(source) or source[position] != ',':
                raise ValueError(f"expected ',' or '}}' at position {position}")
            position = self._skip_whitespace(source, position + 1)

    def _parse_array(self, source: str, position: int, path: str, spans: list[_StringSpan], decoder: json.JSONDecoder) -> int:
        position = self._skip_whitespace(source, position + 1)
        if position < len(source) and source[position] == ']':
            return position + 1
        index = 0
        while True:
            child_path = f"{path}/{index}" if path else f"/{index}"
            position = self._parse_value(source, position, child_path, spans, decoder)
            position = self._skip_whitespace(source, position)
            if position < len(source) and source[position] == ']':
                return position + 1
            if position >= len(source) or source[position] != ',':
                raise ValueError(f"expected ',' or ']' at position {position}")
            index += 1
            position = self._skip_whitespace(source, position + 1)

    @staticmethod
    def _skip_whitespace(source: str, position: int) -> int:
        while position < len(source) and source[position] in " \t\r\n":
            position += 1
        return position
