from dataclasses import replace

from core.events.model import EventType
from filters.json.filter import JsonFilter


def _units(events):
    return [event.resource for event in events if event.type is EventType.TEXT_UNIT]


def test_json_filter_extracts_string_values_and_uses_keys_as_names():
    source = '{"key1": "Text1", "key2": "Text2"}'

    units = _units(JsonFilter().read(source))

    assert [unit.metadata["json_path"] for unit in units] == ["/key1", "/key2"]
    assert [unit.metadata["name"] for unit in units] == ["key1", "key2"]
    assert [unit.fragments[0].parts[0] for unit in units] == ["Text1", "Text2"]


def test_json_filter_round_trip_is_lossless():
    source = '{\n  "key": "Text",\n  "nested": ["One", "Two"]\n}\n'

    assert JsonFilter().round_trip(source) == source


def test_json_filter_writer_replaces_only_string_value_span():
    source = '{"key": "Hello", "keep": "World"}'
    events = list(JsonFilter().read(source))
    unit = _units(events)[0]
    changed = replace(unit, fragments=(replace(unit.fragments[0], parts=("Witaj",)),))
    events = tuple(
        replace(event, resource=changed)
        if event.type is EventType.TEXT_UNIT and event.resource.id == changed.id
        else event
        for event in events
    )

    assert JsonFilter().write(events) == '{"key": "Witaj", "keep": "World"}'


def test_json_filter_respects_extract_all_pairs_and_standalone_parameters():
    source = '{"name": "Named", "items": ["One", "Two"]}'

    units = _units(JsonFilter(parameters={"extractAllPairs": False}).read(source))
    assert [unit.fragments[0].parts[0] for unit in units] == []

    units = _units(JsonFilter(parameters={"extractAllPairs": False, "extractStandalone": True}).read(source))
    assert [unit.fragments[0].parts[0] for unit in units] == ["One", "Two"]


def test_json_filter_respects_full_key_path_and_leading_slash_parameters():
    source = '{"root": {"title": "Hello"}}'

    units = _units(JsonFilter(parameters={"useFullKeyPath": True, "useLeadingSlashOnKeyPath": False}).read(source))
    assert units[0].metadata["name"] == "root/title"

    units = _units(JsonFilter(parameters={"useFullKeyPath": True, "useLeadingSlashOnKeyPath": True}).read(source))
    assert units[0].metadata["name"] == "/root/title"


def test_json_filter_does_not_treat_numeric_object_keys_as_array_items():
    source = '{"123": "Named", "items": ["Standalone"]}'

    units = _units(JsonFilter(parameters={"extractAllPairs": True, "extractStandalone": False}).read(source))
    assert [unit.fragments[0].parts[0] for unit in units] == ["Named"]
